package recipe.dto;

public class RecipeCategoryKindDto {
	private String category_kind_idx;
	private String category_kind_name;
	private String category_idx;
	public String getCategory_kind_idx() {
		return category_kind_idx;
	}
	public void setCategory_kind_idx(String category_kind_idx) {
		this.category_kind_idx = category_kind_idx;
	}
	public String getCategory_kind_name() {
		return category_kind_name;
	}
	public void setCategory_kind_name(String category_kind_name) {
		this.category_kind_name = category_kind_name;
	}
	public String getCategory_idx() {
		return category_idx;
	}
	public void setCategory_idx(String category_idx) {
		this.category_idx = category_idx;
	}
	
	
}