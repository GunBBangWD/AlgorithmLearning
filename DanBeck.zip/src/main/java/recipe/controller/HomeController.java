package recipe.controller;

public class HomeController {

}
